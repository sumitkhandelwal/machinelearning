# Load the CSV file in our envionment
data = read.csv("sample_student_data.csv") 
print (data)# print the all data
print(is.data.frame(data)) # To check the data is correct is not
print(ncol(data)) # find out number of columns 
print(nrow(data)) # find out number of rows
# Take a marks of students predictor variable
x = c(data$Final.Marks)
# Take a Grade of Students as a respondant variable
y = c(data$Grade)
#Find out the relation between marks and grade of students.
relation = lm(y~x) # Apply linear regression on marks and grade of students
print (relation) # Print the summery of student.
# Plot the result and first save the final output file as png format
png(file = "result_linear.png")
# Plot a result
plot(y,x,col = "blue",main = "Marks and grade relations",
     abline(lm(x~y)),cex = 2.0,pch = 1,xlab = "Grade of Students",ylab = "Marks Obtained By STudent")
dev.off()
# Prediction of grade with respect to any mark value entere

a = data.frame(x = 56)
predict_result = predict(relation,a)
round_result=round(predict_result,digits = 0)
print(paste0("The Predicted value as per students marks :", round_result))
# Maximum Marks obtained by Students in a class
ma_marks = max(data$Final.Marks.75.,na.rm = TRUE)
print (as.numeric(ma_marks))
# Manimum Marks obtained by Students in a class
mi_marks = min(data$Final.Marks.75.,na.rm = TRUE)
print (as.numeric(mi_marks))